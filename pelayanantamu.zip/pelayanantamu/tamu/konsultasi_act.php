<?php 
include '../koneksi.php';
$tanggal  = $_POST['tanggal'];
$nama  = $_POST['nama'];
$tgl  = $_POST['tgl'];
$keperluan  = $_POST['keperluan'];
$status  = $_POST['status'];

mysqli_query($koneksi, "insert into konsultasi values (NULL,'$tanggal','$nama','$tgl','$keperluan','$status')")or die(mysqli_error($koneksi));
header("location:konsultasi.php");

