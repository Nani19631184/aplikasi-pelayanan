<?php include 'header.php'; ?>

<div class="content-wrapper">

  <section class="content-header">
    <h1>
      PENDAFTARAN JADWAL NIKAH
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Dashboard</li>
    </ol>
  </section>

  <section class="content">
    <div class="row">
      <section class="col-lg-12">
        <div class="box box-info">
        <div class="alert alert-info text-center">
        <h4><b>INFORMASI</b></h4>
  <h4 class="text-black">Pelaksanaan Akad hanya bisa dilakukan sebanyak 10 pasangan selama sehari.<br>Silahkan cek tanggal dan jam yang anda inginkan pada kolom pencarian sebelum melakukan pendaftaran.</h4>
          </div>
               
          <div class="box-header">
                  
            <div class="btn-group pull-right">            
              <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#exampleModal">
                <i class="fa fa-plus"></i> &nbsp Tambah Data
              </button>
            </div>
    <br>
    <br>
            <?php 
                if(isset($_GET['alert'])){
                  if($_GET['alert']=='gagal'){
                    ?>
                    <div class="alert alert-warning alert-dismissible">
                      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                      <h4><i class="icon fa fa-warning"></i> Peringatan !</h4>
                      Ekstensi Tidak Diperbolehkan
                    </div>                
                    <?php
                  }elseif($_GET['alert']=="berhasil"){
                    ?>
                    <div class="alert alert-success alert-dismissible">
                      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                      <h4><i class="icon fa fa-check"></i> Success</h4>
                      Berhasil Disimpan
                    </div>                
                    <?php
                  }elseif($_GET['alert']=="berhasilupdate"){
                    ?>
                    <div class="alert alert-success alert-dismissible">
                      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                      <h4><i class="icon fa fa-check"></i> Success</h4>
                      Berhasil Update
                    </div>                
                    <?php
                  }
                }
                ?>
          </div>     

          
                 
          <div class="box-body">
          <div align="right">
<h5> Untuk Mencari Data, Silahkan Masukkan Tanggal &nbsp &#8659; &nbsp&nbsp </h5>
    </div>
            <!-- Modal -->
            <form action="jadwal_act.php" method="post">
              <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h4 class="modal-title" id="exampleModalLabel">Tambah Jadwal</h4>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    
                    <div class="modal-body">
                    
                      <div class="form-group">
                        <label>TANGGAL</label>
                        <input type="text" name="tanggal" required="required" class="form-control datepicker2">
                      </div>

                      <div class="form-group">
                        <label>NAMA CATIN BIN/BINTI</label>
                        <input type="text" name="suami" autocomplete="off" class="form-control" placeholder="nama suami..">
                        <input type="text" name="istri" autocomplete="off" class="form-control" placeholder="nama istri..">
                      </div>

                      <div class="form-group">
                        <label>WALI NIKAH (NASAB/HAKIM)</label>
                        <input type="text" name="wali" class="form-control" placeholder="wali nikah ..">
                      </div>                 

                      <div class="form-group">
                        <label>TANGGAL NIKAH</label>
                        <input type="datetime-local" name="tgl" required="required" class="form-control">
                      </div>
                      
                      <div class="form-group">
                        <label>TEMPAT NIKAH</label>
                        <input type="text" name="tempat" class="form-control" placeholder="tempat nikah ..">
                      </div>

                      <div class="form-group">
                        <label>KELURAHAN</label>
                        <input type="text" name="kelurahan" class="form-control" placeholder="kelurahan ..">                        
                      </div>

                      <div class="form-group">
                        <label>PENGHULU</label>
                        <select name="penghulu" class="form-control" required="required">
                          <option value="">- Pilih -</option>
                          <?php 
                          $penghulu = mysqli_query($koneksi,"SELECT * FROM penghulu ORDER BY penghulu ASC");
                          while($k = mysqli_fetch_array($penghulu)){
                            ?>
                            <option value="<?php echo $k['penghulu_id']; ?>"><?php echo $k['penghulu']; ?></option>
                            <?php 
                          }
                          ?>
                        </select>                   
                      </div>

                      <div class="form-group">
                      <label>KET/NO.HP</label>
                      <textarea name="keterangan" class="form-control" rows="3"></textarea>
                      </div>                     

                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                      <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                  </div>
                </div>
              </div>
            </form>


            <div class="table-responsive">
            
              <table class="table table-bordered table-striped" id="table-datatable">
                
                <thead>
                  <tr>
                    <th width="1%" rowspan="2">NO</th>
                    <th width="10%" rowspan="2" class="text-center">TANGGAL</th>
                    <th colspan="2" class="text-center">NAMA CATIN</th>
                    <th rowspan="2" class="text-center">WALI<br>NIKAH</th>
                    <th rowspan="2" class="text-center">TANGGAL<br>NIKAH</th>
                    <th rowspan="2" class="text-center">TEMPAT<br>NIKAH</th>
                    <th rowspan="2" class="text-center">KELURAHAN</th>
                    <th rowspan="2" class="text-center">PENGHULU</th>
                  </tr>
                  <tr>
                    <th class="text-center">SUAMI</th>
                    <th class="text-center">ISTRI</th>
                  </tr>


                </thead>

                 <tbody>
                  <?php 
                  include '../koneksi.php';
                  $no=1;
                  $data = mysqli_query($koneksi,"SELECT * FROM jadwal,penghulu where penghulu.penghulu_id=jadwal.penghulu");
                   while($d = mysqli_fetch_array($data)){
                   ?>
                    <tr>
                      <td class="text-center"><?php echo $no++; ?></td>
                      <td><?php echo $d['jadwal_tanggal']; ?></td>
                      <td><?php echo $d['suami']; ?></td>
                      <td><?php echo $d['istri']; ?></td>
                      <td><?php echo $d['wali']; ?></td>
                      <td><?php echo $d['jadwal_tgl']; ?></td>                  
                      <td><?php echo $d['tempat_nikah']; ?></td>                                            
                      <td><?php echo $d['kelurahan']; ?></td>
                      <td><?php echo $d['penghulu']; ?></td>                      
                     
                      
                  </tr>
                  <?php 
                }
                ?>
              </tbody>
            </table>
            
          </div>
        </div>        
        
      </div>
    </section>
  </div>
</section>


</div>
<?php include 'footer.php'; ?>

