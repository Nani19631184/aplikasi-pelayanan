<?php 
include '../koneksi.php';
$id  = $_POST['id'];
$tanggal  = $_POST['tanggal'];
$nama  = $_POST['nama'];
$alamat  = $_POST['alamat'];
$kelurahan  = $_POST['kelurahan'];
$kategori  = $_POST['kategori'];
$no  = $_POST['no'];

mysqli_query($koneksi, "update tamu set tamu_tanggal='$tanggal', tamu_nama='$nama', tamu_alamat='$alamat', tamu_kelurahan='$kelurahan', kategori='$kategori', tamu_nohp='$no' where tamu_id='$id'") or die(mysqli_error($koneksi));
header("location:tamu.php?alert=berhasilupdate");
