<?php 
include '../koneksi.php';
$tanggal  = $_POST['tanggal'];
$nama_s  = $_POST['nama_s'];
$nama_i  = $_POST['nama_i'];
$tgl_nikah = $_POST['tgl_nikah'];
$status  = $_POST['status'];


mysqli_query($koneksi, "insert into bukunikah values (NULL,'$tanggal','$nama_s','$nama_i','$tgl_nikah','$status')");
header("location:bukunikah.php");