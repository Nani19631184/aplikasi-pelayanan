<?php 
include '../koneksi.php';
$tanggal  = $_POST['tanggal'];
$nama  = $_POST['nama'];
$alamat  = $_POST['alamat'];
$kelurahan = $_POST['kelurahan'];
$kategori  = $_POST['kategori'];
$no  = $_POST['no'];


mysqli_query($koneksi, "insert into tamu values (NULL,'$tanggal','$nama', '$alamat', '$kelurahan','$kategori', '$no')")or die(mysqli_error($koneksi));;
header("location:tamu.php?alert=berhasil");

// mysqli_query($koneksi, "insert into tamu values (NULL,'$tanggal','$nama','$alamat','$kelurahan','$keperluan','$no')")or die(mysqli_error($koneksi));
// header("location:tamu.php");