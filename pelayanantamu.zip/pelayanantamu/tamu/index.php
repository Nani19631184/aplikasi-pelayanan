<?php include 'header.php'; ?>

<div class="content-wrapper">

  <section class="content-header">
    <h1>
      Dashboard
      
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Dashboard</li>
     </ol>
  </section>


  <section class="content">

    <div class="row">

      <div class="col-lg-3 col-xs-6">
        <div class="small-box bg-blue-gradient">
          <div class="inner">
            <?php 
            $tamu = mysqli_query($koneksi,"SELECT * FROM tamu");
            $jml_tamu = mysqli_num_rows($tamu);
            ?>
            <h4 style="font-weight: bolder"><?php echo number_format($jml_tamu, 0,",","."); ?></h4>
            <p>TAMU</p>
            <br>
          </div>
          <div class="icon">
            <i class="ion ion-person"></i>
          </div>
          <a href="tamu.php" class="small-box-footer">Selengkapnya <i class="fa fa-arrow-circle-right"></i></a>
        </div>
      </div>

      <div class="col-lg-3 col-xs-6">
        <div class="small-box bg-yellow-gradient">
          <div class="inner">
            <?php 
            $jadwal = mysqli_query($koneksi,"SELECT * FROM jadwal");
            $jml_jadwal = mysqli_num_rows($jadwal);
            ?>
            <h4 style="font-weight: bolder"><?php echo number_format($jml_jadwal, 0,",","."); ?></h4>
            <p>DATA JADWAL NIKAH</p>
          <br>
          </div>
          <div class="icon">
            <i class="ion ion-calendar"></i>
          </div>
          <a href="jadwal.php" class="small-box-footer">Selengkapnya <i class="fa fa-arrow-circle-right"></i></a>
        </div>
      </div>

      <div class="col-lg-3 col-xs-6">
        <div class="small-box bg-green-gradient">
          <div class="inner">
            <?php 
            $bukunikah = mysqli_query($koneksi,"SELECT * FROM bukunikah WHERE status LIKE '%0%'");
            $jml_bukunikah = mysqli_num_rows($bukunikah);
            ?>
            <h4 style="font-weight: bolder"><?php echo number_format($jml_bukunikah, 0,",","."); ?></h4>
            <p>PENGAMBILAN BUKU NIKAH</p>
            <h4><span class="label label-warning badge-pill">Proses</span></h4>
          </div>
          <div class="icon">
            <i class="ion ion-document"></i>
          </div>
          <a href="bukunikah.php" class="small-box-footer">Selengkapnya <i class="fa fa-arrow-circle-right"></i></a>
        </div>
      </div>

      <div class="col-lg-3 col-xs-6">
        <div class="small-box bg-red-gradient">
          <div class="inner">
            <?php 
            $konsultasi = mysqli_query($koneksi,"SELECT * FROM konsultasi WHERE status LIKE '%0%'");
            $jml_konsultasi = mysqli_num_rows($konsultasi);
            ?>
            <h4 style="font-weight: bolder"><?php echo number_format($jml_konsultasi, 0,",","."); ?></h4>
            <p>KONSULTASI</p>
            <h4><span class="label label-warning badge-pill">Proses</span></h4>
          </div>
          <div class="icon">
            <i class="ion ion-chatboxes"></i>
          </div>
          <a href="konsultasi.php" class="small-box-footer">Selengkapnya <i class="fa fa-arrow-circle-right"></i></a>
        </div>
      </div>


      </section>
      <!-- right col -->
    </div>










  </section>

</div>







<?php include 'footer.php'; ?>