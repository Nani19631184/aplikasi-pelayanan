<?php 
include '../koneksi.php';
$tanggal  = $_POST['tanggal'];
$suami = $_POST['suami'];
$istri = $_POST['istri'];
$wali = $_POST['wali'];
$tgl = $_POST['tgl'];
$tempat = $_POST['tempat'];
$kelurahan = $_POST['kelurahan'];
$penghulu = $_POST['penghulu'];
$keterangan  = $_POST['keterangan'];

mysqli_query($koneksi, "insert into jadwal values (NULL,'$tanggal','$suami','$istri','$wali','$tgl','$tempat','$kelurahan','$penghulu','$keterangan')")or die(mysqli_error($koneksi));
header("location:jadwal.php?alert=berhasil");

