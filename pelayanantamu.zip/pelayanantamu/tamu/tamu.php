<?php include 'header.php'; ?>

<div class="content-wrapper">

  <section class="content-header">
    <h1>
      TAMU
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Dashboard</li>
    </ol>
  </section>

  <section class="content">
    <div class="row">
      <section class="col-lg-12">
        <div class="box box-info">
        <div class="alert alert-info text-center">
        <b><h4  class="text-black">SILAHKAN ISI DAFTAR TAMU</h4></b>
        </div>
          <div class="box-header">
            <h3 class="box-title">Daftar Tamu</h3>
            <div class="btn-group pull-right">            
              
              <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#exampleModal">
                <i class="fa fa-plus"></i> &nbsp Tambah Tamu
              </button>


            </div>
          </div>      
          <div class="box-body">
          <div align="right">
<h5> Untuk Mencari Data, Silahkan Masukkan Tanggal &nbsp &#8659; &nbsp&nbsp </h5>
    </div>

            <!-- Modal -->
            <form action="tamu_act.php" method="post" 
              <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h4 class="modal-title" id="exampleModalLabel">Tambah Tamu</h4>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">

                      <div class="form-group">
                        <label>Tanggal</label>
                        <input type="text" name="tanggal" required="required" class="form-control datepicker2">
                      </div>

                      <div class="form-group">
                        <label>Nama</label>
                        <input type="text" name="nama" autocomplete="off" class="form-control" placeholder="nama ..">
                      </div>
                      

                      <div class="form-group">
                        <label>Alamat</label>
                        <input type="text" name="alamat" class="form-control" placeholder="alamat ..">
                      </div>

                      <div class="form-group">
                        <label>Kelurahan</label>
                        <input type="text" name="kelurahan" class="form-control" placeholder="kelurahan ..">
                      </div>

                      <div class="form-group">
                        <label>Keperluan</label>
                        <select name="kategori" class="form-control" required="required">
                          <option value="">- Pilih -</option>
                          <?php 
                          $kategori = mysqli_query($koneksi,"SELECT * FROM kategori ORDER BY kategori ASC");
                          while($k = mysqli_fetch_array($kategori)){
                            ?>
                            <option value="<?php echo $k['kategori_id']; ?>"><?php echo $k['kategori']; ?></option>
                            <?php 
                          }
                          ?>
                        </select>
                      </div>

                      <div class="form-group">
                        <label>No HP</label>
                        <input type="text" name="no" class="form-control" placeholder="nomor hp ..">
                      </div>

                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                      <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                  </div>
                </div>
              </div>
            </form>


            <div class="table-responsive">
              <table class="table table-bordered table-striped" id="table-datatable">
                <thead>
                  <tr>
                    <th width="1%">NO</th>
                    <th>TANGGAL</th>
                    <th>NAMA</th>
                    <th>ALAMAT</th>
                    <th>KELURAHAN</th>
                    <th>KEPERLUAN</th>
                  </tr>
                </thead>

                <tbody>
                  <?php 
                  include '../koneksi.php';
                  $no=1;
                 $data = mysqli_query($koneksi,"SELECT * FROM tamu,kategori where kategori.kategori_id=tamu.kategori ORDER BY tamu_id DESC");
                 $no=1;
                  while($d = mysqli_fetch_array($data)){
                    ?>
                     <tr>
                      <td class="text-center"><?php echo $no++; ?></td>
                      <td><?php echo date('d-m-Y', strtotime($d['tamu_tanggal'])); ?></td>
                      <td><?php echo $d['tamu_nama']; ?></td>
                      <td><?php echo $d['tamu_alamat']; ?></td>
                      <td><?php echo $d['tamu_kelurahan']; ?></td>
                      <td><?php echo $d['kategori']; ?></td>
                        
                     
                    </tr>
                    <?php 
                  }
                  ?>
                </tbody>
              </table>
            </div>
          </div>

        </div>
      </section>
    </div>
  </section>

</div>
<?php include 'footer.php'; ?>