<?php 
include '../koneksi.php';
$id  = $_GET['id'];

mysqli_query($koneksi, "delete from tamu where tamu_id='$id'");
header("location:tamu.php");