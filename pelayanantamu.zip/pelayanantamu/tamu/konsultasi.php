<?php include 'header.php'; ?>

<div class="content-wrapper">

  <section class="content-header">
    <h1>
     KONSULTASI     
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Dashboard</li>
    </ol>
  </section>

  <section class="content">
    <div class="row">
      <section class="col-lg-12">
        <div class="box box-info">
        
          <div class="box-header">
            <h3 class="box-title">DATA KONSULTASI</h3>
            <div class="btn-group pull-right">            

              <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#exampleModal">
                <i class="fa fa-plus"></i> &nbsp Tambah 
              </button>
            </div>
          </div>
          <div class="box-body">
          <div align="right">
<h5> Untuk Mencari Data, Silahkan Masukkan Tanggal &nbsp &#8659; &nbsp&nbsp </h5>
    </div>


            <!-- Modal -->
            <form action="konsultasi_act.php" method="post">
              <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">Tambah konsultasi</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">

                      <div class="form-group">
                        <label>TANGGAL</label>
                        <input type="text" name="tanggal" required="required" class="form-control datepicker2">
                      </div>

                      <div class="form-group">
                        <label>NAMA</label>
                        <input type="text" name="nama" autocomplete="off" class="form-control" placeholder="nama ..">
                      </div>

                      <div class="form-group">
                        <label>TANGGAL KONSULTASI</label>                      
                        <input type="datetime-local" name="tgl" required="required" class="form-control">
                      </div>

                      <div class="form-group">
                        <label>KEPERLUAN</label>
                        <input type="text" name="keperluan" class="form-control" placeholder="Konsultasi tentang..">
                      </div>

                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                      <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                  </div>
                </div>
              </div>
            </form>


            <div class="table-responsive">
              <table class="table table-bordered table-striped" id="table-datatable">
                <thead>
                  <tr>
                    <th width="1%">NO</th>
                    <th>TANGGAL</th>
                    <th>NAMA</th>
                    <th>TANGGAL KONSULTASI</th>
                    <th>KEPERLUAN</th>
                    <th>STATUS</th>
                  </tr>
                </thead>
                <tbody>
                  <?php 
                  include '../koneksi.php';
                  $no=1;
                  $data = mysqli_query($koneksi,"SELECT * FROM konsultasi");
                  while($d = mysqli_fetch_array($data)){
                    ?>
                    <tr>
                      <td><?php echo $no++; ?></td>
                      <td><?php echo $d['tanggal']; ?></td>
                      <td><?php echo $d['nama']; ?></td>
                      <td><?php echo $d['tgl']; ?></td>
                      <td><?php echo $d['keperluan']; ?></td>
                      <td><?php

										if ($d['status'] == 0) {

										echo "<span class='label label-warning badge-pill'>Proses</span>";
										}
										else{
										echo "<span class='label label-pill label-success'>Selesai</span>";
										
									}?></td> 

                    </tr>
                    <?php 
                  }
                  ?>
                </tbody>
              </table>
            </div>
          </div>

        </div>
      </section>
    </div>
  </section>

</div>
<?php include 'footer.php'; ?>